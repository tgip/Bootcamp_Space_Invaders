package org.academiadecodigo.bootcamp;

public interface Moveable {

    void move();

    /**
     *
     */

}
