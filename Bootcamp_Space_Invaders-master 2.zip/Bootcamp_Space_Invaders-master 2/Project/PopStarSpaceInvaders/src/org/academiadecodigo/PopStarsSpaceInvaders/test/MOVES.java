package org.academiadecodigo.simplegraphics.test;

public enum MOVES {
    RIGHT,
    LEFT,
    UP,
    DOWN;



}
