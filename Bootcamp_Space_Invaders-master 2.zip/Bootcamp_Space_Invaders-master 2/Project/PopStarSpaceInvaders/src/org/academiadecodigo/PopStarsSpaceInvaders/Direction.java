package org.academiadecodigo.bootcamp;

public enum Direction {
    LEFT,
    RIGHT,
    SPACE,
    UP
}
