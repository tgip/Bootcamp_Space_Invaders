package org.academiadecodigo.simplegraphics.test;

import org.academiadecodigo.simplegraphics.graphics.Rectangle;

public class AbcTester {

    public static void main(String[] args) {

       Move move=new Move();





    }
}
