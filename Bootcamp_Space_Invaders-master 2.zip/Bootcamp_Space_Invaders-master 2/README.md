# Bootcamp_Space_Invaders

Edit this file when ...
If you want to create a task, preface list items with [ ].
To mark a task as complete, use [x].
If your working on something ... put WIP in front of the [ ] and add your name (so we don't all work on the same thing ...)

TODO : 

- [ ] Everything ...
- [ ] Make a test routine in main() to test simplegraphics
- [ ] WIP Define BadGuy Object - Humberto
  - [ ] WIP Define BadGuy Interface(Killable?) - Humberto
- [ ] Define Player Object- Soares
- [ ] Define "Play Area" Object
- [ ] Define "Position"
- [ ] Buy Humberto beer !
