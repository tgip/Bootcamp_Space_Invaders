package screens;

import org.academiadecodigo.simplegraphics.mouse.Mouse;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public class Screen extends JComponent implements ActionListener {

    //@Override
    public void keyPressed(MouseEvent e) {}


    public void keyReleased(MouseEvent e) {}

    @Override
    public void actionPerformed(ActionEvent e) {}


}
