package org.academiadecodigo.PopStarsSpaceInvaders.grid;

public enum GridType {
    SIMPLE_GFX
}
