package org.academiadecodigo.PopStarsSpaceInvaders.grid;

public enum GridColor {

    RED,
    GREEN,
    BLUE,
    MAGENTA,
    NOCOLOR
}
