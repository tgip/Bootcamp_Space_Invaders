package org.academiadecodigo.PopStarsSpaceInvaders;


import org.academiadecodigo.simplegraphics.graphics.Color;
import org.academiadecodigo.simplegraphics.graphics.Rectangle;

public class Shot extends Check {

    private Rectangle rectangle;
    private int health;
    private Direction direction;
    private double posX;
    private double posY;


    public Shot(double originX, double originY) {

        rectangle = new Rectangle(originX,originY, 5, 5);
        rectangle.setColor(Color.BLACK);
        rectangle.draw();
        rectangle.fill();

    }

    public void move(){
        rectangle.translate(0, -1);
        setPosY(getPosY()-2);
    }

    public double getPosX() {
        return posX;
    }

    public double getPosY() {
        return posY;
    }

    public void setPosX(double posX) {
        this.posX = posX;
    }

    public void setPosY(double posY) {
        this.posY = posY;
    }

    public void setDirection(Direction direction) {
        this.direction = Direction.UP;
    }
}
