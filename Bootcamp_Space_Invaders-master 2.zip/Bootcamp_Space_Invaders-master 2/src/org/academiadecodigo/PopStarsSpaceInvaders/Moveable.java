package org.academiadecodigo.PopStarsSpaceInvaders;

public interface Moveable {

    public void move(double xPos, double yPos);

    /**
     *
     */

}
