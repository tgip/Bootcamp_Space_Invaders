package org.academiadecodigo.PopStarsSpaceInvaders;

public enum Levels {
    LEVEL1,
    LEVEL2,
    LEVEL3
}
