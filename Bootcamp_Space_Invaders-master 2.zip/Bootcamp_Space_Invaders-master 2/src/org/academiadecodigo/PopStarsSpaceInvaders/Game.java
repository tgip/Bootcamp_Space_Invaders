package org.academiadecodigo.PopStarsSpaceInvaders;

import org.academiadecodigo.PopStarsSpaceInvaders.gameobjects.badguys.BadGuy01;
import org.academiadecodigo.PopStarsSpaceInvaders.gameobjects.badguys.GenericBadGuy;
import org.academiadecodigo.PopStarsSpaceInvaders.gameobjects.Player;
import org.academiadecodigo.PopStarsSpaceInvaders.grid.Grid;
import org.academiadecodigo.PopStarsSpaceInvaders.simplegfx.SimpleGfxGrid;
import org.academiadecodigo.simplegraphics.graphics.Movable;

import java.awt.Dimension;

import java.util.LinkedList;

import javax.swing.JPanel;

/**
 * The game logic
 */
public class Game  {

    private Dimension d;
    private GenericBadGuy badGuys;
    private Player player;
    private Shot[] shot = new Shot[1];
    private SimpleGfxGrid simpleGfxGrid;


    private CollisionDetector collisionDetector;


    public void init() {
        player = new Player();
        MouseListener mouseListener = new MouseListener(player);
        badGuys = new BadGuy01(90,90);
        simpleGfxGrid = new SimpleGfxGrid(100, 200);
        simpleGfxGrid.init();

    }

    public void start() throws InterruptedException {

       while (true) {

            // detectCollisions

            collisionDetector = new CollisionDetector();
            Thread.sleep(100);
            badGuys.move();
            for(Shot i:player.list){
                i.move();
            }






            //otherObjectsMove(); // for future

            //moveShots();
           // moveShot();
            //moveEnemy();
           //moveEnemy();
        }

    }

   /* public void moveEnemy(){
        for(GenericBadGuy gb : badGuys){
            gb.move();
            collisionDetector.check(gb);
        }
    } */

   /* public void moveShot(){
        for(Shot sh : shot){
            sh.move(0,-1);
            //collisionDetector.check(sh);
        }
    } */
}
