package org.academiadecodigo.PopStarsSpaceInvaders;

public enum Direction {
    LEFT,
    RIGHT,
    SPACE,
    UP,
    DOWN;
}
